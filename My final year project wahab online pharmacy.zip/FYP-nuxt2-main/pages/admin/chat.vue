<template>
  <div class="flex ">
    <adminNav />
    <!-- Users List  -->
    <users />

  </div>
</template>
