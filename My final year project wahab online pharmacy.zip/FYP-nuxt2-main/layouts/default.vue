<template>
  <div>
    
    <Nuxt />
   
  </div>
</template>



<style scoped>
body{
  scroll-behavior: smooth;
}
</style>