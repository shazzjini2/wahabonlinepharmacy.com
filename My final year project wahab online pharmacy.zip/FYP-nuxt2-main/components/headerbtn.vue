<template>
  <button
    class="
      border-2 border-white
      text-white
      font-bold
      hover:scale-105
      rounded
      py-1.5
      px-2
      btn
      

    "
  >
    <slot></slot>
  </button>
</template>

<script>

export default {};
</script>

<style>

</style>